if __name__ == '__main__':
    import datamart_geo.main

    datamart_geo.main.main()
